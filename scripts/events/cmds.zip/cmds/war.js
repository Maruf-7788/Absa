module.exports = {
  config: {
    name: "war",
    version: "1.0",
    author: "Xemon",
    role: 2,
    category: "admin",
    guide: {
      vi: "Not Available",
      en: "cpx @(mention)"
    } 
  },

  onStart: async function ({ api, event, userData, args }) {
      var mention = Object.keys(event.mentions)[0];
    if(!mention) return api.sendMessage("Need to tag 1 friend whome you want to scold with bad words", event.threadID);
 let name =  event.mentions[mention];
    var arraytag = []; 
        arraytag.push({id: mention, tag: name});
    var a = function (a) { api.sendMessage(a, event.threadID); }
setTimeout(() => {a({body: "তর মার ভোদায় পাব্লিক টয়লেট 🥵তর মায়ের ভুদাতে পোকা 🥵তর বাপের হোল তর বউয়ের ভোদাতেদিমু " + " " + name, mentions: arraytag})}, 3000);
setTimeout(() => {a({body: "আবাল চোদা কান্দে ফালাইয়া তর মায়েরে চুদি🥵🥵" + " " + name, mentions: arraytag})}, 5000);
setTimeout(() => {a({body: "ভুদার বেটা  তর মা এর ভুদায় ধান ছড়াইয়া চড়ুই দিয়া খাওয়ামু❤" + " " + name, mentions: arraytag})}, 7000);
setTimeout(() => {a({body: "হোগার ভিতরে ভইড়া দিমু…ঠ্যাঁঙ কাইট্টা পুটকি দা ভইরা দুম! হালা ল্যাওড়া চোদা" + " " + name, mentions: arraytag})}, 9000);
setTimeout(() => {a({body: "হোগার ভিতরে ভইড়া দিমু…ঠ্যাঁঙ কাইট্টা পুটকি দা ভইরা দুম! হালা ল্যাওড়া চোদা💋" + " " + name, mentions: arraytag})}, 12000);
setTimeout(() => {a({body: "শুয়োরের বাচ্চা কুত্তার বাচ্ছা হারামির বাচ্চা হারামি হারামজাদা হারামখোর খান্কি মাগির পোলা😭" + " " + name, mentions: arraytag})}, 14000);
setTimeout(() => {a({body: "কান্দে ফালাইয়া তর মায়েরে চুদিI" + " " + name, mentions: arraytag})}, 16000);
setTimeout(() => {a({body: "কান্দে ফালাইয়া তর মায়েরে চুদি 🤠❤" + " " + name, mentions: arraytag})}, 18000);
setTimeout(() => {a({body: "ধোন কাইট্টা কুত্তা দিয়া খাওয়ামু" + " " + name, mentions: arraytag})}, 20000);
setTimeout(() => {a({body: "তোগোরে ফাসিতে লটকাইয়া চুদমু" + " " + name, mentions: arraytag})}, 22000);
setTimeout(() => {a({body: "তোগোর ধোন টাইনা তোগোর পিছন দিয়া ঢুকামু💋" + " " + name, mentions: arraytag})}, 2400);
setTimeout(() => {a({body: ". জং ধরা লোহা দিয়া পাকিস্তানের মানচিত্র বানাই্য়া তোদের পিছন দিয়া ঢুকামু" + " " + name, mentions: arraytag})}, 26000);
setTimeout(() => {a({body: "তর মায়ের ভোদা শিরিষ কাগজ দিয়া ঘইষা দিমু।" + " " + name, mentions: arraytag})}, 28000);
setTimeout(() => {a({body: "তর মায়ের ভোদা শিরিষ কাগজ দিয়া ঘইষা দিমু।😭💋" + " " + name, mentions: arraytag})}, 30000);
setTimeout(() => {a({body: "তর মায়ের ভোদা বোম্বাই মরিচ দিয়া চুদামু। " + " " + name, mentions: arraytag})}, 32000);
setTimeout(() => {a({body: "তর বাপের পুটকির ফুটা দিয়া কাডল ঢুকামু।" + " " + name, mentions: arraytag})}, 65000);
setTimeout(() => {a({body: "তর বৌয়ের ভোদায় মাগুর মাছ চাষ করুম। " + " " + name, mentions: arraytag})}, 34000);
setTimeout(() => {a({body: "হাতির ল্যাওড়া দিয়া তর মায়েরে চুদুম।🤠❤" + " " + name, mentions: arraytag})}, 36000);
setTimeout(() => {a({body: "তর মায়ের ভোদা ছিল্লা লবণ লাগায় দিমু।" + " " + name, mentions: arraytag})}, 38000);
setTimeout(() => {a({body: "তোর মা বোন বউ রে একসাথে একটা কনডম দিয়ে চুদি🤠❤" + " " + name, mentions: arraytag})}, 40000);
setTimeout(() => {a({body: "তর মায়ের ভোদা ছিল্লা লবণ লাগায় দিমু।" + " " + name, mentions: arraytag})}, 44000);
setTimeout(() => {a({body: "খাংকির পোলা তোর মা রে গাছ এর সাথে বেধে ভুদার মধ্যে তালগাছ ঢুকিয়ে চুদি🥵 " + " " + name, mentions: arraytag})}, 460000);
setTimeout(() => {a({body: "বেস্যা কনডম ফাটা ভুদা ছিড়া তোর মা রে সোফায় ফালায়া চুদি🤠🫀" + " " + name, mentions: arraytag})}, 48000);
setTimeout(() => {a({body: "বেস্যা কনডম ফাটা ভুদা ছিড়া তোর মা রে সোফায় ফালায়া চুদি" + " " + name, mentions: arraytag})} , 50000);
setTimeout(() => {a({body: "তর মাকে আলমারির সাথে বেঁধে চুদি যাতে আরামে চুদা যায়" + " " + name, mentions: arraytag})} , 52000);
setTimeout(() => {a({body: "আওয়ামীলীগ এর সভাপতি বঙ্গবীর কাদের সিদ্দিকী বীরউত্তম বীরবিক্রম এর ভার্সন অ্যান্ড্রয়েড এ রেখে তুর মাকে লেংটা করে তোর মার ভোদায় আগুন দিবো পারলে ঠেকাইস" + " " + name, mentions: arraytag})} , 56000);
setTimeout(() => {a({body: "বিদুৎ এর কারেন্ট তর মা র ভুদায় প্রবেশ করিয়ে ইলেকট্রনিক সর্ট দিয়ে তর মাকে চুদি🙀❤" + " " + name, mentions: arraytag})} , 58000);
setTimeout(() => {a({body: "তোর মা রে মাসিক আটকাইয়া মেরে ফেলবো😘" + " " + name, mentions: arraytag})} , 60000);
setTimeout(() => {a({body: "সিন দে ভাচুয়াল এর ফাপরবাজ চুদাস রিয়েল লাইফে ত বাসা থেকে বের হস না তর মাকে ২টাকার কন্ডম দিয়ে চুদে😻" + " " + name, mentions: arraytag})} , 62000);
setTimeout(() => {a({body: "তোর মা রে মাসিক আটকাইয়া মেরে ফেলবো❤"+ " " + name, mentions: arraytag})} , 64000);
setTimeout(() => {a({body: "তর মারে পদ্মা সেতুর ৭নাম্বার পিলারের সাথে হাত পা বেদে কালা কুত্তা দিয়ে চুদাই🤠❤" + " " + name, mentions: arraytag})} , 66000);
setTimeout(() => {a({body: "তোর মা রে মাসিক আটকাইয়া মেরে ফেলবো❤" + " " + name, mentions: arraytag})} , 68000);
setTimeout(() => {a({body: "হোগার ভিতরে ভইড়া দিমু…ঠ্যাঁঙ কাইট্টা পুটকি দা ভইরা দুম! হালা ল্যাওড়া চোদা" + " " + name, mentions: arraytag})} , 70000);
setTimeout(() => {a({body: "শুয়োরের বাচ্চা কুত্তার বাচ্ছা হারামির বাচ্চা হারামি হারামজাদা হারামখোর খান্কি মাগির পোলা🤠❤" + " " + name, mentions: arraytag})} , 72000);
setTimeout(() => {a({body: "আবাল চোদা কান্দে ফালাইয়া তর মায়েরে চুদি🥵🥵" + " " + name, mentions: arraytag})} , 74000);
setTimeout(() => {a({body: "তর মার ভোদায় পাব্লিক টয়লেট 🥵তর মায়ের ভুদাতে পোকা 🥵তর বাপের হোল তর বউয়ের ভোদাতেদিমু🤠❤" + " " + name, mentions: arraytag})} , 76000);
setTimeout(() => {a({body: "শুয়োরের বাচ্চা কুত্তার বাচ্ছা হারামির বাচ্চা হারামি হারামজাদা হারামখোর খান্কি মাগির পোলা❤" + " " + name, mentions: arraytag})} , 78000);
setTimeout(() => {a({body: "তোগোরে ফাসিতে লটকাইয়া চুদমু" + " " + name, mentions: arraytag})} , 80000);
setTimeout(() => {a({body: "তর মায়ের ভোদা শিরিষ কাগজ দিয়া ঘইষা দিমু।" + " " + name, mentions: arraytag})} , 82000);
setTimeout(() => {a({body: "তর বাপের পুটকির ফুটা দিয়া কাডল ঢুকামু।" + " " + name, mentions: arraytag})} , 84000);
setTimeout(() => {a({body: "XEMON THE GREAT EXIT!!😾🥀🤣" + " " + name, mentions: arraytag})} , 84000);
  }
};
